"""Battle traces: record, save, load, and VERIFY by re-simulation.

A trace is two things at once:
  * a replay in the sense calibration.json means -- seed + initial setup + the
    command log + periodic state hashes -- which ``verify_trace`` re-simulates
    and checks hash by hash; and
  * enough per-frame entity data (positions, hp, radius) for ``render.py`` to
    draw the battle as a self-contained HTML page without an engine
    (``python -m royalegym.render trace.msgpack -o battle.html``).

Encoding is msgspec msgpack (``.msgpack``, compact) or JSON (``.json``, for
eyeballing). Per-entity rows use ``array_like`` structs, so a frame is a list of
short arrays; the header names the columns so the viewer reads them by name
(render.py refuses a trace that lacks a column it draws).
State hashes are hex strings, because a u64 does not survive a JavaScript Number.

SPELLS (2026-09-13). A frame also records the engine's live spell objects
(``BattleState.spells``) and, through ``EntityState``, each entity's stun and
knockback timers; the header names the spell columns in ``spell_fields``. Both are
trailing fields with defaults, so a version-1 trace recorded before they existed still
decodes (with no spells and zero timers) and the version number did not move. A
MockEngine trace has no spell objects: its spells resolve inside a tick.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import TYPE_CHECKING, Any

import msgspec

from .protocol import (
    CardInfo,
    DeployCommand,
    DeployResult,
    Engine,
    EntityState,
    MatchSetup,
    ProjectileState,
    SpellState,
)

if TYPE_CHECKING:
    from .state_mutator import Snapshot

TRACE_FORMAT = "royalegym-trace"
TRACE_VERSION = 1


class TraceStep(msgspec.Struct, array_like=True):
    tick: int  # engine tick before the commands were applied
    ticks: int  # ticks requested
    commands: list[DeployCommand]
    statuses: list[int]
    # WHAT THE ENGINE ALREADY RESOLVED, kept instead of thrown away. A DeployResult carries
    # the card the slot held and the position the deploy actually used; this struct used to
    # keep only the status, so a trace could say a command succeeded and not say what it
    # played or where it ended up.
    #
    # WHY card_ids IS NOT RECONSTRUCTABLE FROM THE TRACE. The obvious route is the hand:
    # decode the command's slot and read `frames[...].hands`. It is wrong by one. Frames are
    # recorded AFTER `engine.step(commands, ...)` (see `ClashParallelEnv._advance`), so the
    # frame nearest a step shows the hand the play already cycled -- the REPLACEMENT card,
    # not the card played. The correct frame is the previous step's trailing one, which is a
    # rule nobody reading a trace would guess and which fails silently when guessed wrong.
    # Asked for by train, who could measure tile concentration but could not split it BY
    # CARD.
    #
    # WHY landed IS WORTH THE BYTES. It is the RESOLVED position, so for a building whose
    # footprint did not fit it is where the engine moved it rather than where the policy
    # tapped. With the command beside it a trace can measure relocation on the policy's OWN
    # distribution of taps, which a uniform sweep over legal tiles cannot stand in for: the
    # rate depends on where the policy chooses to play.
    #
    # Trailing and defaulted, like `spells` and `next_cards`, because `array_like=True`
    # makes fields positional and an older trace is simply a shorter array.
    card_ids: list[int] = []
    landed: list[list[int]] = []  # [[x, y], ...] ENGINE frame, parallel to commands


class TraceFrame(msgspec.Struct, array_like=True):
    tick: int
    entities: list[EntityState]
    elixir_milli: list[int]
    crowns: list[int]
    hands: list[list[int]]
    state_hash: str
    spells: list[SpellState] = []  # live spell objects (trailing: older traces decode)
    # The card each seat draws NEXT, which the hand alone does not say. A replay without it
    # has to report the cycle as unknown, and guessing it would be worse. Trailing and
    # defaulted for the same reason `spells` is: `array_like=True` means fields are
    # positional, so a trace recorded before this existed is a shorter array and still
    # decodes, with []. Asked for by train, whose player block reported it unknown.
    next_cards: list[int] = []
    # Projectiles in flight, so a REPLAY can draw arrows and tower shots. EntityState's new
    # fields ride into a trace for free because a frame stores entities wholesale; these do
    # not, and the owner watches battles through replays built from traces, so anything
    # absent here never reaches the screen however complete the engine's export is.
    # Trailing and defaulted: an older trace is a shorter array and decodes with [].
    projectiles: list[ProjectileState] = []
    # Each player's special-form rows, as the state gives them (``PlayerState.evo`` and
    # ``PlayerState.abilities``): the evolution counters and the ability buttons. The header
    # records the deck's forms once, but a replay draws an evolution coming up or a button
    # pressed only from these, so they go in every frame. Trailing and defaulted as above.
    evo: list[list[list[int]]] = []
    abilities: list[list[list[int]]] = []


class TraceHeader(msgspec.Struct):
    format: str
    version: int
    seed: int
    setup: MatchSetup | None
    snapshot: bytes | None
    frame_every_tick: bool
    tick_ms: int
    subtile: int
    tiles_x: int
    tiles_y: int
    half: int
    grid: list[list[int]]
    bridges_half_cols: list[tuple[int, int]]
    water_half_rows: tuple[int, int]
    cards: list[CardInfo]
    entity_fields: list[str]
    frame_fields: list[str]
    step_fields: list[str]
    spell_fields: list[str] = []  # SpellState columns; empty in a pre-spell trace
    # The card table the recording engine read (its ``card_table_stamp()``). An engine
    # fills the ones it states; "" is "not stated", which is also what an older trace
    # decodes with. RustEngine: the first three. MockEngine: vintage and loaded hash.
    cards_vintage: str = ""
    cards_json_fnv1a64: str = ""
    cards_json_hash_source: str = ""
    cards_loaded_fnv1a64: str = ""
    # ProjectileState columns, named like spell_fields so a reader decodes a frame's
    # projectile rows by name. Empty in a trace recorded before projectiles existed.
    projectile_fields: list[str] = []
    # Which ENGINE recorded it (its ``engine_identity()``), taken in the recording process:
    # the data compiled in and the binary itself. The card table above says what was
    # read; these say what read it, which moves on every rebuild that loads a new card.
    # "" = not stated: MockEngine, and every trace from before 2026-09-25.
    build_digest: str = ""
    engine_binary_sha256: str = ""
    # The ledger arms the recording engine ran instead of the shipped ones (RustEngine's
    # ``calibration_overrides``, as JSON text per key). The build says nothing about them:
    # an overridden engine plays other battles on the same binary. {} = none, which is also
    # what a trace from before 2026-09-26 decodes with.
    calibration_overrides: dict[str, str] = {}
    # The unit-type vocabulary ``EntityState.unit_type`` indexes (``Engine.unit_types()``,
    # royalesim 0.1.17 on), so a reader names each unit by type. [] = not said: MockEngine, an
    # older engine, and every trace from before 2026-10-05.
    unit_types: list[str] = []


class TraceResult(msgspec.Struct):
    winner: int
    crowns: list[int]
    final_tick: int
    final_hash: str


class Trace(msgspec.Struct):
    header: TraceHeader
    steps: list[TraceStep]
    frames: list[TraceFrame]
    result: TraceResult | None = None


def _hex(h: int) -> str:
    return f"{h & ((1 << 64) - 1):016x}"


# The TraceHeader fields an engine's ``card_table_stamp()`` can fill.
CARD_TABLE_FIELDS = (
    "cards_vintage",
    "cards_json_fnv1a64",
    "cards_json_hash_source",
    "cards_loaded_fnv1a64",
)


def _card_table_fields(engine: Engine) -> dict[str, str]:
    """The header's card-table fields, from an engine that states its table.

    ``card_table_stamp`` is not part of ``protocol.Engine``, so an engine without one
    records a trace with the fields left "".
    """
    stamp = getattr(engine, "card_table_stamp", None)
    if stamp is None:
        return {}
    return {k: str(v) for k, v in stamp().items() if k in CARD_TABLE_FIELDS}


# The TraceHeader fields an engine's ``engine_identity()`` can fill.
ENGINE_IDENTITY_FIELDS = ("build_digest", "engine_binary_sha256")


def _engine_identity_fields(engine: Engine) -> dict[str, str]:
    """The header's engine fields, from an engine that states them ("" otherwise)."""
    identity = getattr(engine, "engine_identity", None)
    if identity is None:
        return {}
    return {k: str(v) for k, v in identity().items() if k in ENGINE_IDENTITY_FIELDS}


def _unit_types(engine: Engine) -> list[str]:
    """The engine's unit-type vocabulary for the header, [] when it says none."""
    said = getattr(engine, "unit_types", None)
    names = said() if callable(said) else None
    return list(names) if names is not None else []


def _override_fields(engine: Engine) -> dict[str, dict[str, str]]:
    """The header's ``calibration_overrides``, from an engine that has any ({} otherwise)."""
    overrides = getattr(engine, "calibration_overrides", None) or {}
    if not overrides:
        return {}
    return {"calibration_overrides": {k: json.dumps(v) for k, v in overrides.items()}}


def _another_engine(header: TraceHeader, engine: Engine) -> str | None:
    """One line naming how the verifying engine differs from the recording one, or None.

    Identity fields are compared only where BOTH state them, so an old trace or a MockEngine
    says nothing. Overrides are compared always: none recorded means none were run.
    """
    have = _engine_identity_fields(engine)
    moved = [
        f"{k} {getattr(header, k)} there and {have[k]} here"
        for k in ENGINE_IDENTITY_FIELDS
        if getattr(header, k) and have.get(k) and getattr(header, k) != have[k]
    ]
    here = _override_fields(engine).get("calibration_overrides", {})
    if header.calibration_overrides != here:
        moved.append(f"calibration_overrides {header.calibration_overrides} there and {here} here")
    if not moved:
        return None
    return (
        "the trace was recorded on another engine (" + "; ".join(moved) + "). A rebuilt "
        "engine can move every hash while the battle itself does not change, for instance "
        "when a newly loadable card shifts the card indices the hash reads, so the lines "
        "below may say only that."
    )


def _frame(engine: Engine) -> TraceFrame:
    s = engine.state()
    return TraceFrame(
        tick=s.tick,
        entities=list(s.entities),
        elixir_milli=[p.elixir_milli for p in s.players],
        crowns=[p.crowns for p in s.players],
        hands=[list(p.hand) for p in s.players],
        state_hash=_hex(engine.state_hash()),
        spells=list(s.spells),
        next_cards=[p.next_card for p in s.players],
        projectiles=list(s.projectiles),
        evo=[[list(r) for r in p.evo] for p in s.players],
        abilities=[[list(r) for r in p.abilities] for p in s.players],
    )


class ReplayRecorder:
    """Attach to an env (``recorder=``). Keeps the most recent trace in ``trace``.

    ``frame_every_tick=True`` records a frame per engine tick (smooth viewing,
    and the tightest determinism check); False records one per decision.
    ``on_finish`` is called with each completed trace, e.g. to save it.
    """

    def __init__(self, frame_every_tick: bool = True, on_finish: Any = None) -> None:
        self.frame_every_tick = frame_every_tick
        self.on_finish = on_finish
        self.trace: Trace | None = None
        self._open = False

    def begin(self, engine: Engine, seed: int, init: MatchSetup | Snapshot) -> None:
        a = engine.arena()
        setup = init if isinstance(init, MatchSetup) else None
        snapshot = None if setup is not None else init.blob  # type: ignore[union-attr]
        header = TraceHeader(
            format=TRACE_FORMAT,
            version=TRACE_VERSION,
            seed=seed,
            setup=setup,
            snapshot=snapshot,
            frame_every_tick=self.frame_every_tick,
            tick_ms=engine.state().tick_ms,
            subtile=a.subtile,
            tiles_x=a.tiles_x,
            tiles_y=a.tiles_y,
            half=a.half,
            grid=a.grid,
            bridges_half_cols=list(a.bridges_half_cols),
            water_half_rows=a.water_half_rows,
            cards=list(engine.cards()),
            entity_fields=list(EntityState.__struct_fields__),
            frame_fields=list(TraceFrame.__struct_fields__),
            step_fields=list(TraceStep.__struct_fields__),
            spell_fields=list(SpellState.__struct_fields__),
            projectile_fields=list(ProjectileState.__struct_fields__),
            **_card_table_fields(engine),
            **_engine_identity_fields(engine),
            **_override_fields(engine),
            unit_types=_unit_types(engine),
        )
        self.trace = Trace(header=header, steps=[], frames=[_frame(engine)])
        self._open = True

    def record_frame(self, engine: Engine) -> None:
        if self._open and self.trace is not None:
            self.trace.frames.append(_frame(engine))

    def record_step(
        self,
        tick: int,
        ticks: int,
        commands: list[DeployCommand],
        results: list[DeployResult],
    ) -> None:
        if self._open and self.trace is not None:
            self.trace.steps.append(
                TraceStep(
                    tick,
                    ticks,
                    list(commands),
                    [r.status for r in results],
                    [r.card_id for r in results],
                    [[r.x, r.y] for r in results],
                )
            )

    def end(self, engine: Engine) -> Trace | None:
        if not self._open or self.trace is None:
            return None
        s = engine.state()
        self.trace.result = TraceResult(
            winner=s.winner,
            crowns=[p.crowns for p in s.players],
            final_tick=s.tick,
            final_hash=_hex(engine.state_hash()),
        )
        self._open = False
        if self.on_finish is not None:
            self.on_finish(self.trace)
        return self.trace


def save_trace(trace: Trace, path: str | Path) -> Path:
    """Write a recorded battle to ``path`` (msgpack, or JSON when it ends in ``.json``) and
    return the path. ``royaleviser PATH`` opens it."""
    p = Path(path)
    data = msgspec.json.encode(trace) if p.suffix == ".json" else msgspec.msgpack.encode(trace)
    p.write_bytes(data)
    return p


def load_trace(path: str | Path) -> Trace:
    """Read a battle ``save_trace`` wrote (msgpack, or JSON when it ends in ``.json``)."""
    p = Path(path)
    raw = p.read_bytes()
    if p.suffix == ".json":
        return msgspec.json.decode(raw, type=Trace)
    return msgspec.msgpack.decode(raw, type=Trace)


def verify_trace(trace: Trace, engine: Engine) -> list[str]:
    """Re-simulate ``trace`` on ``engine`` and list every divergence (empty = identical).

    Checks the catalogue first, then the deploy statuses of every step, every recorded
    frame hash, and the final hash. The first divergence is usually the informative one;
    later ones are consequences.

    WHEN THE REPLAY DIVERGES AND THE ENGINE IS ANOTHER BUILD, the first line says so,
    naming both. It is said only on a divergence: a different binary that replays exactly
    is ordinary (a CI runner compiles its own), and the note is there so that a list of
    hash lines is not read as a changed battle when it may be a changed build.

    THE CARDS A SETUP DEALS ARE COMPARED BY NAME first. A setup names its cards by
    POSITION (a deck is a list of catalogue ids), and the catalogue renumbers whenever a
    card becomes loadable, so the same setup on an engine with a different table deals
    different cards: the first deploy diverges and the hash list says nothing about why.
    So when a dealt id names another card on this engine, or none, the result is one
    line naming it, and nothing is replayed. Only the ids the setup uses are compared: an
    id no deck or spawn holds changes nothing a replay reads. A trace that starts from a
    snapshot is not compared, since the snapshot holds the engine's own card indices.
    """
    h = trace.header
    if h.setup is not None:
        have = [c.name for c in engine.cards()]
        named = {c.card_id: c.name for c in h.cards}
        dealt = sorted(
            {c for deck in h.setup.decks for c in deck} | {s.card_id for s in h.setup.spawns}
        )
        differ = [
            (cid, named.get(cid), have[cid] if 0 <= cid < len(have) else None)
            for cid in dealt
            if not 0 <= cid < len(have) or have[cid] != named.get(cid)
        ]
        if differ:
            cid, want, got = differ[0]
            return [
                f"card {cid} is {want} in the trace and {got or 'absent'} on this engine "
                f"({len(differ)} of the {len(dealt)} card ids the setup deals differ). Replay "
                "it on the engine kind and build that recorded it, loaded with the trace's "
                "own card list (card_names=[c.name for c in trace.header.cards] for a "
                "RustEngine). A build that loads a card the recording build refused moves "
                "every hash as well, so such a trace verifies only on the recording build."
            ]
    problems: list[str] = []
    if h.setup is not None:
        engine.reset(h.seed, h.setup)
    elif h.snapshot is not None:
        engine.load_state(h.snapshot)
    else:
        return ["trace has neither setup nor snapshot"]
    frames = iter(trace.frames)

    def check_frame() -> None:
        want = next(frames, None)
        if want is None:
            problems.append(f"tick {engine.state().tick}: more frames simulated than recorded")
            return
        got = _hex(engine.state_hash())
        if got != want.state_hash:
            problems.append(f"tick {want.tick}: hash {got} != recorded {want.state_hash}")

    check_frame()
    for i, st in enumerate(trace.steps):
        if engine.state().tick != st.tick:
            problems.append(f"step {i}: engine at tick {engine.state().tick}, trace says {st.tick}")
        if h.frame_every_tick:
            results = engine.step(st.commands, 1)
            check_frame()
            for _ in range(st.ticks - 1):
                if engine.state().game_over:
                    break
                engine.step([], 1)
                check_frame()
        else:
            results = engine.step(st.commands, st.ticks)
            check_frame()
        got_status = [r.status for r in results]
        if got_status != st.statuses:
            problems.append(f"step {i}: statuses {got_status} != recorded {st.statuses}")
    if trace.result is not None and _hex(engine.state_hash()) != trace.result.final_hash:
        problems.append("final hash differs")
    if problems:
        note = _another_engine(h, engine)
        if note is not None:
            problems.insert(0, note)
    return problems


class SavingReplayRecorder(ReplayRecorder):
    """A recorder that WRITES completed traces, so a rollout worker can produce them.

    WHY THIS EXISTS RATHER THAN ``on_finish``
        ``ReplayRecorder`` already takes ``on_finish``, and for a script that is the better
        tool. It is unreachable from a training run: the recorder is an ``EnvFactory``
        COMPONENT, given as an importable class plus JSON kwargs, and a callable is not
        something JSON can express. So a worker that gets a pickled recipe can be handed
        this class and a directory, and cannot be handed a function. Every argument here is
        a string, an int or a bool for that reason.

        Asked for by train, who had built and measured the rest: a 3-minute battle is 3,601
        frames and 1.6 MB on disk, and their viewer plays one to a real viewer at wall clock
        in 57 MB. Watching a live run cannot work -- `time/collection` is 4.35 s of a 62.94 s
        iteration, and those 4.35 seconds hold about 82,000 engine ticks, so it is a firehose
        between silences rather than slow gameplay. Replaying a saved trace is the form that
        works, and the training run producing them was the one missing piece.

    WHAT IT COSTS THE RUN
        One write every ``every`` completed episodes, and nothing else. Recording itself is
        whatever ``frame_every_tick`` already costs; this adds serialisation of a finished
        trace, not per-tick work.

    THREE THINGS IT DOES THAT A NAIVE VERSION WOULD NOT, each because a rollout worker is
    not a script:
        * **The PID is in the name.** Workers are separate PROCESSES with separate counters,
          so two of them would otherwise write the same ``000050`` file and one would win.
        * **The write is atomic**, via a temporary file and ``os.replace``. A viewer reading
          the directory while a worker writes would otherwise find a half-written trace, and
          msgpack does not fail loudly on one.
        * **The directory is created and tested at CONSTRUCTION**, so a bad path fails when
          the config is loaded rather than after the first episode of a five-hour run. A
          recorder that silently saves nothing is the failure train hit from the other side:
          a publisher that reported "3601 frames, 0 sent" and looked like it worked.
    """

    def __init__(
        self,
        out_dir: str,
        every: int = 50,
        keep: int = 4,
        frame_every_tick: bool = True,
    ) -> None:
        super().__init__(frame_every_tick=frame_every_tick)
        if every < 1:
            raise ValueError(f"every must be >= 1, got {every}: 0 would save nothing quietly")
        if keep < 1:
            raise ValueError(f"keep must be >= 1, got {keep}: 0 would delete what it just wrote")
        self.out_dir = Path(out_dir)
        self.every = every
        self.keep = keep
        # Fail here, not after the first episode. mkdir raises on an unusable path.
        self.out_dir.mkdir(parents=True, exist_ok=True)
        self.completed = 0
        self.saved: list[Path] = []

    def end(self, engine: Engine) -> Trace | None:
        trace = super().end(engine)
        if trace is None:
            return None
        self.completed += 1
        if self.completed % self.every == 0:
            self.saved.append(self._write(trace))
            self._prune()
        return trace

    def _write(self, trace: Trace) -> Path:
        """Atomically, because a viewer may be reading this directory as we write."""
        tick = trace.result.final_tick if trace.result is not None else 0
        name = f"{os.getpid()}-{self.completed:06d}-tick{tick}.msgpack"
        final = self.out_dir / name
        tmp = final.with_suffix(".msgpack.part")
        tmp.write_bytes(msgspec.msgpack.encode(trace))
        os.replace(tmp, final)
        return final

    def _prune(self) -> None:
        """Keep the newest ``keep`` of OUR OWN files.

        Only this process's, because another worker's traces are not ours to delete and a
        directory shared by eight workers would otherwise have each of them deleting the
        others' newest files.
        """
        while len(self.saved) > self.keep:
            old = self.saved.pop(0)
            old.unlink(missing_ok=True)
